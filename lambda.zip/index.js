import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";

const s3 = new S3Client({ region: "eu-north-1" });

export async function handler() {
    const bucket = "inno-bucket-brownj58-1773317244122";

    try {
        const res = await s3.send(
            new GetObjectCommand({
                Bucket: bucket,
                Key: "index.html"
            })
        );

        const body = await res.Body.transformToString();

        return {
            statusCode: 200,
            headers: { "Content-Type": "text/html" },
            body
        };
    } catch (err) {
        console.error(err);
        return {
            statusCode: 500,
            headers: { "Content-Type": "text/plain" },
            body: "Error loading page"
        };
    }
}
